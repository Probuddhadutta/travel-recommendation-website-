/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, FormEvent, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Palmtree, 
  Church, 
  Globe, 
  Mail, 
  Info, 
  Home as HomeIcon, 
  Menu, 
  X, 
  MapPin, 
  Compass,
  Users,
  Target,
  Send,
  Search,
  RotateCcw
} from 'lucide-react';

// --- Types ---
type Page = 'home' | 'about' | 'contact';

interface Destination {
  id: string;
  name: string;
  description: string;
  images: string[];
  type: 'beach' | 'temple' | 'country';
}

// --- Data ---
const BEACHES: Destination[] = [
  {
    id: 'b1',
    name: 'Maldives',
    description: 'Relax on the pristine white sand and clear turquoise waters of the Indian Ocean. Perfect for snorkeling and luxury retreats.',
    images: [
      'https://picsum.photos/seed/maldives1/800/600',
      'https://picsum.photos/seed/maldives2/800/600'
    ],
    type: 'beach'
  },
  {
    id: 'b2',
    name: 'Bali',
    description: 'Explore scenic beaches with surf-friendly waves and tropical vibes in Indonesia. A hub for culture and relaxation.',
    images: [
      'https://picsum.photos/seed/bali1/800/600',
      'https://picsum.photos/seed/bali2/800/600'
    ],
    type: 'beach'
  }
];

const TEMPLES: Destination[] = [
  {
    id: 't1',
    name: 'Angkor Wat',
    description: 'Marvel at the intricate architecture and spiritual serenity of Cambodia\'s ancient heart. The largest religious monument in the world.',
    images: [
      'https://picsum.photos/seed/angkor1/800/600',
      'https://picsum.photos/seed/angkor2/800/600'
    ],
    type: 'temple'
  },
  {
    id: 't2',
    name: 'Golden Temple',
    description: 'Experience the divine beauty and golden splendor of Amritsar, India. A symbol of brotherhood and equality.',
    images: [
      'https://picsum.photos/seed/goldentemple1/800/600',
      'https://picsum.photos/seed/goldentemple2/800/600'
    ],
    type: 'temple'
  }
];

const COUNTRIES: Destination[] = [
  {
    id: 'c1',
    name: 'Japan',
    description: 'A perfect blend of ancient culture, stunning nature, and cutting-edge technology. From neon cities to zen gardens.',
    images: [
      'https://picsum.photos/seed/mtfuji/800/600',
      'https://picsum.photos/seed/kyoto/800/600'
    ],
    type: 'country'
  },
  {
    id: 'c2',
    name: 'Italy',
    description: 'Experience history, art, and world-class cuisine in the heart of the Mediterranean. Home to the most UNESCO sites.',
    images: [
      'https://picsum.photos/seed/colosseum/800/600',
      'https://picsum.photos/seed/venice/800/600'
    ],
    type: 'country'
  },
  {
    id: 'c3',
    name: 'USA',
    description: 'From bustling metropolises like NYC to breathtaking national parks, the USA offers endless variety for every traveler.',
    images: [
      'https://picsum.photos/seed/nyc/800/600',
      'https://picsum.photos/seed/grandcanyon/800/600'
    ],
    type: 'country'
  }
];

const ALL_DESTINATIONS = [...BEACHES, ...TEMPLES, ...COUNTRIES];

// --- Components ---

const Navbar = ({ currentPage, setPage }: { currentPage: Page, setPage: (p: Page) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home', icon: HomeIcon },
    { id: 'about', label: 'About Us', icon: Info },
    { id: 'contact', label: 'Contact Us', icon: Mail },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setPage('home')}>
            <Compass className="w-8 h-8 text-emerald-600" />
            <span className="text-xl font-bold tracking-tight text-stone-900">Wanderlust</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => setPage(link.id as Page)}
                className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-emerald-600 ${
                  currentPage === link.id ? 'text-emerald-600' : 'text-stone-600'
                }`}
              >
                <link.icon className="w-4 h-4" />
                {link.label}
              </button>
            ))}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-stone-600">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-stone-200 overflow-hidden"
          >
            <div className="px-4 py-4 space-y-4">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    setPage(link.id as Page);
                    setIsOpen(false);
                  }}
                  className={`flex items-center gap-3 w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    currentPage === link.id ? 'bg-emerald-50 text-emerald-600' : 'text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <link.icon className="w-5 h-5" />
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const SectionHeader = ({ title, subtitle, icon: Icon }: { title: string, subtitle: string, icon: any }) => (
  <div className="mb-12 text-center">
    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mb-4">
      <Icon className="w-6 h-6" />
    </div>
    <h2 className="text-3xl font-bold text-stone-900 mb-4">{title}</h2>
    <p className="text-stone-600 max-w-2xl mx-auto">{subtitle}</p>
  </div>
);

const DestinationCard: React.FC<{ dest: Destination }> = ({ dest }) => (
  <motion.div 
    layout
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    whileHover={{ y: -5 }}
    className="bg-white rounded-2xl overflow-hidden shadow-sm border border-stone-100 group h-full flex flex-col"
  >
    <div className="grid grid-cols-2 gap-1">
      {dest.images.slice(0, 2).map((img, idx) => (
        <div key={idx} className="aspect-[4/3] overflow-hidden">
          <img 
            src={img} 
            alt={`${dest.name} view ${idx + 1}`} 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </div>
      ))}
    </div>
    <div className="p-6 flex-grow flex flex-col">
      <div className="flex items-center gap-2 text-emerald-600 mb-2">
        <MapPin className="w-4 h-4" />
        <span className="text-xs font-bold uppercase tracking-wider">{dest.type}</span>
      </div>
      <h3 className="text-xl font-bold text-stone-900 mb-2">{dest.name}</h3>
      <p className="text-stone-600 text-sm leading-relaxed flex-grow">{dest.description}</p>
    </div>
  </motion.div>
);

const Home = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDestinations = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const query = searchQuery.toLowerCase();
    return ALL_DESTINATIONS.filter(d => 
      d.name.toLowerCase().includes(query) || 
      d.type.toLowerCase().includes(query) ||
      d.description.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/travel-hero-v2/1920/1080?blur=2" 
            alt="Hero" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-white"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-bold text-stone-900 mb-6 tracking-tight"
          >
            Discover Your Next <span className="text-emerald-600">Adventure</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg md:text-xl text-stone-700 leading-relaxed mb-12"
          >
            Welcome to Wanderlust Explorer! We help you discover your perfect travel destination based on your preferences. 
            Explore pristine beaches, ancient temples, and vibrant countries with rich multimedia content.
          </motion.p>
          
          {/* Interactive Search Bar */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="relative max-w-xl mx-auto"
          >
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5" />
              <input 
                type="text" 
                placeholder="Search by destination, type (beach, temple), or country..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-2xl border border-stone-200 bg-white shadow-xl shadow-stone-200/50 focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-stone-900"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Search Results or Default Sections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatePresence mode="wait">
          {filteredDestinations ? (
            <motion.div 
              key="search-results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <div className="flex items-center justify-between border-b border-stone-100 pb-4">
                <h2 className="text-2xl font-bold text-stone-900">
                  Search Results for "{searchQuery}"
                </h2>
                <span className="text-stone-500 text-sm">{filteredDestinations.length} found</span>
              </div>
              {filteredDestinations.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredDestinations.map(dest => <DestinationCard key={dest.id} dest={dest} />)}
                </div>
              ) : (
                <div className="text-center py-24 bg-stone-50 rounded-3xl">
                  <Compass className="w-12 h-12 text-stone-300 mx-auto mb-4" />
                  <p className="text-stone-500">No destinations found matching your search. Try "beach" or "Japan".</p>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="default-sections"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-32"
            >
              {/* Beach Section */}
              <section id="beach">
                <SectionHeader 
                  title="Top Beach Destinations" 
                  subtitle="Unwind on the world's most beautiful shores, from secluded coves to vibrant tropical paradises."
                  icon={Palmtree}
                />
                <div className="grid md:grid-cols-2 gap-8">
                  {BEACHES.map(dest => <DestinationCard key={dest.id} dest={dest} />)}
                </div>
              </section>

              {/* Temple Section */}
              <section id="temple">
                <SectionHeader 
                  title="Sacred Temples" 
                  subtitle="Journey through time and spirituality at these ancient architectural wonders."
                  icon={Church}
                />
                <div className="grid md:grid-cols-2 gap-8">
                  {TEMPLES.map(dest => <DestinationCard key={dest.id} dest={dest} />)}
                </div>
              </section>

              {/* Country Section */}
              <section id="countries">
                <SectionHeader 
                  title="Explore by Country" 
                  subtitle="Dive deep into the unique cultures, landscapes, and experiences of our featured nations."
                  icon={Globe}
                />
                <div className="grid md:grid-cols-3 gap-8">
                  {COUNTRIES.map(dest => <DestinationCard key={dest.id} dest={dest} />)}
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const About = () => (
  <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center mb-16"
    >
      <h1 className="text-4xl md:text-5xl font-bold text-stone-900 mb-6">About Wanderlust Explorer</h1>
      <p className="text-lg text-stone-600 max-w-3xl mx-auto">
        We are a team of passionate travelers dedicated to helping you explore the world's most incredible destinations 
        with personalized recommendations and expert guides.
      </p>
    </motion.div>

    <div className="grid md:grid-cols-2 gap-16 items-center mb-24">
      <div>
        <img 
          src="https://picsum.photos/seed/about-team-v2/800/600" 
          alt="Our Team" 
          referrerPolicy="no-referrer"
          className="rounded-3xl shadow-xl"
        />
      </div>
      <div className="space-y-8">
        <div className="flex gap-4">
          <div className="flex-shrink-0 w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-stone-900 mb-2">Our Mission</h3>
            <p className="text-stone-600">To inspire and empower travelers to discover authentic experiences and create lifelong memories through curated, high-quality travel insights.</p>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="flex-shrink-0 w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-stone-900 mb-2">Our Team</h3>
            <p className="text-stone-600">A diverse group of globetrotters, photographers, and writers who have collectively visited over 100 countries to bring you the best advice.</p>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="flex-shrink-0 w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-stone-900 mb-2">Expert Tips</h3>
            <p className="text-stone-600">We provide more than just lists; we offer deep dives into local customs, hidden gems, and practical travel logistics.</p>
          </div>
        </div>
      </div>
    </div>

    <div className="bg-stone-50 rounded-3xl p-12 text-center">
      <h2 className="text-3xl font-bold text-stone-900 mb-8">Why Choose Us?</h2>
      <div className="grid sm:grid-cols-3 gap-8">
        <div>
          <div className="text-4xl font-bold text-emerald-600 mb-2">500+</div>
          <div className="text-stone-600 font-medium">Destinations</div>
        </div>
        <div>
          <div className="text-4xl font-bold text-emerald-600 mb-2">50k+</div>
          <div className="text-stone-600 font-medium">Happy Travelers</div>
        </div>
        <div>
          <div className="text-4xl font-bold text-emerald-600 mb-2">10+</div>
          <div className="text-stone-600 font-medium">Years Experience</div>
        </div>
      </div>
    </div>
  </div>
);

const Contact = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    alert('Message Sent! Thank you for contacting us.');
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-stone-900 mb-4">Get in Touch</h1>
          <p className="text-stone-600">Have questions about a destination? We'd love to hear from you. Send us a message and we'll get back to you as soon as possible.</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-sm border border-stone-100 space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-semibold text-stone-700 mb-2">Name</label>
            <input
              type="text"
              id="name"
              required
              value={formState.name}
              onChange={(e) => setFormState({ ...formState, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
              placeholder="Your name"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-semibold text-stone-700 mb-2">Email</label>
            <input
              type="email"
              id="email"
              required
              value={formState.email}
              onChange={(e) => setFormState({ ...formState, email: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
              placeholder="your@email.com"
            />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-semibold text-stone-700 mb-2">Message</label>
            <textarea
              id="message"
              required
              rows={5}
              value={formState.message}
              onChange={(e) => setFormState({ ...formState, message: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all resize-none"
              placeholder="How can we help you?"
            ></textarea>
          </div>
          <button
            type="submit"
            className="w-full bg-emerald-600 text-white font-bold py-4 rounded-xl hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-100"
          >
            Send Message
            <Send className="w-5 h-5" />
          </button>
        </form>

        <div className="mt-12 grid sm:grid-cols-2 gap-8">
          <div className="flex items-center gap-4 p-6 bg-stone-50 rounded-2xl">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-emerald-600 shadow-sm">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-stone-900">Email Us</div>
              <div className="text-sm text-stone-600">hello@wanderlust.com</div>
            </div>
          </div>
          <div className="flex items-center gap-4 p-6 bg-stone-50 rounded-2xl">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-emerald-600 shadow-sm">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-stone-900">Office</div>
              <div className="text-sm text-stone-600">San Francisco, CA</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [page, setPage] = useState<Page>('home');

  return (
    <div className="min-h-screen bg-white font-sans text-stone-900 selection:bg-emerald-100 selection:text-emerald-900">
      <Navbar currentPage={page} setPage={setPage} />
      
      <main>
        <AnimatePresence mode="wait">
          <motion.div
            key={page}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
          >
            {page === 'home' && <Home />}
            {page === 'about' && <About />}
            {page === 'contact' && <Contact />}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="bg-stone-900 text-stone-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <Compass className="w-6 h-6 text-emerald-500" />
              <span className="text-white font-bold text-lg">Wanderlust Explorer</span>
            </div>
            <div className="flex gap-8 text-sm">
              <button onClick={() => setPage('home')} className="hover:text-white transition-colors">Home</button>
              <button onClick={() => setPage('about')} className="hover:text-white transition-colors">About Us</button>
              <button onClick={() => setPage('contact')} className="hover:text-white transition-colors">Contact Us</button>
            </div>
            <div className="text-sm">
              © {new Date().getFullYear()} Wanderlust Explorer. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
